@echo off
chcp 65001 >nul
title Project Zomboid Offline - Migration Repair
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0migrate.ps1"
if errorlevel 1 pause
exit
