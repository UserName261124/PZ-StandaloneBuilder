﻿================================================================
     Project Zomboid 独立版 —— 迁移修复工具  使用说明
================================================================

【什么时候用这个工具】

把整个独立版文件夹复制到新电脑、或者换了盘符/换了目录之后用。
作用：把 mods 里的目录联接重新接上，并重写便携启动 bat，
同时生成一份要填进 Steam 的启动参数。

文件不会丢。联接只是“快捷方式”，源文件都在 Zomboid\workshop_src 里。


================================================================
【操作步骤】
================================================================

1. 关闭游戏
   任务管理器确认没有 ProjectZomboid64.exe 进程。

2. 双击 迁移修复_Repair.bat

3. 第①步：选择独立版根目录
   就是同时包含 ProjectZomboid 和 Zomboid 的那一层文件夹。

4. 第②步：确认工坊原始包位置
   - 正常情况下脚本会自动找到 Zomboid\workshop_src，直接往下走
   - 如果没找到、或者 workshop_src 是空的，
     会弹窗问你是否手动指定，选「是」后弹出文件夹选择框，
     请选择真正的工坊原始包目录：
        首选  <独立版根目录>\Zomboid\workshop_src
        也可以用  Steam 的 steamapps\workshop\content\108600
        或者你自己整理的、文件夹名是 mod 名的扁平目录
     选错了会提示"路径无效"并让你重选，不会误操作。

5. 第③步：确认执行
   弹窗会列出：
        独立版根目录
        工坊源目录
        源结构（工坊ID\mods 还是 扁平目录）
        现有联接数量、其中失效（死链）数量
   点「是」开始。执行内容：
        - 删除 mods 下全部旧联接（只删链接，不动真实文件）
        - 按 modversion → versionMin → 工坊ID 择优，用 mklink /J 重建
        - 重写 启动独立版_Start.bat（使用 %~dp0 自适应路径）
        - 生成 Steam启动参数_SteamOptions.txt

6. 查看结果
   完成弹窗会显示：新建多少个、当前总数、失败几个、哪些没有 mod.info。

7. 按 Steam启动参数_SteamOptions.txt 填 Steam
   打开 <独立版根目录>\Steam启动参数_SteamOptions.txt，照着填（见下一节）。


================================================================
【Steam 启动选项里的 -cachedir 怎么改】
================================================================

改的位置：Steam 客户端 → 库 → 找到这个非Steam游戏条目
→ 右键 → 属性 → 三个框

1. 目标（Target）
   填新电脑上 exe 的真实路径：
       新路径\ProjectZomboid\ProjectZomboid64.exe
   注意：这个框只放 exe，不要把参数写进来。

2. 起始位置（Start In）
   填：
       新路径\ProjectZomboid

3. 启动选项（Launch Options）
   把 -cachedir= 后面引号里的路径，换成新电脑上的
   Zomboid 文件夹真实路径：
       -agentlib:zbNative=policy=allow-all -- -cachedir="新路径\Zomboid" -modfolders mods

   三个要点：
   a. -cachedir 必须是绝对路径，例如
      D:\Games\PZ_Offline\Zomboid
      不能写相对路径，不能写 %~dp0
   b. 路径带空格，必须用英文双引号括起来
   c. -modfolders 后面只能写关键字 mods，
      不能写 -modfolders="D:\...\mods"
      写成带路径的会被游戏当成 unknown option 丢弃

   改完直接点关闭，不需要重启 Steam。
   下次从这个条目启动，读的就是新路径下的存档和模组。

另外两个可选框：
   名称：可以改成 "PZ 独立版" 之类，方便和正版区分
   图标：可选 新路径\ProjectPomboid\ 里的 ico


================================================================
【检查改对了没有】
================================================================

启动后看日志 新路径\Zomboid\console.txt：
  - 出现 独立版路径\Zomboid\mods\xxx        → 路径对了
  - 出现 unknown option "-modfolders=..."    → 启动选项写错
  - 出现 workshop\content\108600             → 还在读创意工坊

游戏里打开模组面板，任选一个模组看右侧：
  Path   = 独立版路径\Zomboid\mods\xxx   → 正确
  Source = Mods                          → 正确


================================================================
【硬性注意事项】
================================================================

1. 整个独立版必须放在同一个 NTFS 分区里，
   workshop_src 不能单独挪到别的盘（junction 不支持跨分区）
2. 资源管理器直接复制文件夹时，联接会被当成普通文件夹把内容复制一遍，
   体积翻倍。要省时间用：
        robocopy "旧目录" "新目录" /E /SL /R:1 /W:1
3. 路径别太长，整体控制在 200 字符以内，否则 Java 读不到深层文件
4. 别勾选 ModLoadOrderSorter_b42，它会重写 default.txt 打乱顺序
5. mods\default.txt 是启用清单，若变成空的 mods{} 表示全部未启用，
   用 Steam 版原文件覆盖即可


================================================================
【常见问题】
================================================================

问：弹窗说找不到 workshop_src？
答：选「是」手动指定。优先选 独立版\Zomboid\workshop_src。

问：提示"路径无效"？
答：所选文件夹里既没有『数字工坊ID\mods』结构，
    也没有直接含 mod.info 的 mod 文件夹。重新选。

问：重建后模组还是没加载？
答：先看 mods\default.txt 是否是空的 mods{}；
    再确认启动参数是 -modfolders mods（关键字，不是路径）。

问：联接数比以前少？
答：同名模组只保留一个（按版本择优），这是正常行为，
    完成弹窗里会列出被丢弃的是哪些。

问：能不能只修联接、不动 Steam 设置？
答：可以。重建联接和生成参数文本是分开的，
    Steam 那边你不改就还是旧路径，但启动 bat 已经可用。


================================================================
        Project Zomboid Standalone - Migration Repair (EN)
================================================================

[Language] The script is bilingual: run 迁移修复_Repair.bat, a small window asks
中文 / English, and every dialog after that follows your choice.
One script, no separate English copy.

[When to use it]

After copying the standalone folder to a new PC, or after the drive letter
or folder path changed. It reconnects the junctions in mods and rewrites
the portable launcher, and regenerates the Steam launch options file.

No files are lost. Junctions are just links; the real files live in
Zomboid\workshop_src.


================================================================
[Steps]
================================================================

1. Close the game
   Make sure no ProjectZomboid64.exe is running.

2. Run 迁移修复_Repair.bat and pick 中文 / English

3. Step 1: pick the standalone root
   The folder that contains both ProjectZomboid and Zomboid.

4. Step 2: confirm the workshop source location
   - Normally the script finds Zomboid\workshop_src automatically
   - If it is missing, or workshop_src is empty, a dialog asks whether to
     pick the folder manually. Choose Yes, then select the real source:
         first choice  <root>\Zomboid\workshop_src
         also fine     Steam's steamapps\workshop\content\108600
         also fine     your own flat folder where each folder is a mod name
     A wrong pick shows "Invalid folder" and lets you pick again, so it
     cannot damage anything.

5. Step 3: confirm the run
   The dialog lists root, workshop source, source layout, existing junction
   count and how many are dangling. Click Yes to proceed. It will:
        - delete all old junctions in mods (links only, real files untouched)
        - rebuild every junction with mklink /J, choosing the newest by
          modversion -> versionMin -> workshop ID
        - rewrite the portable launcher using %~dp0
        - regenerate the Steam launch options file

6. Check the result dialog: created, total, skipped, failed, and which
   folders have no mod.info.

7. Fill in Steam using the generated file
   Open <root>\Steam启动参数_SteamOptions.txt and copy the three values (see below).


================================================================
[How to change -cachedir in Steam]
================================================================

Where: Steam client -> Library -> the non-Steam entry -> right-click ->
Properties -> three fields

1. Target
   The exe on the new machine:
       <new path>\ProjectZomboid\ProjectZomboid64.exe
   Do not put parameters here.

2. Start In
       <new path>\ProjectZomboid

3. Launch Options
   Replace the path inside the quotes after -cachedir with the real
   Zomboid folder on the new machine:
       -agentlib:zbNative=policy=allow-all -- -cachedir="<new path>\Zomboid" -modfolders mods

   Three rules:
   a. -cachedir must be absolute, e.g.
      D:\Games\PZ_Offline\Zomboid
      No relative paths, no %~dp0
   b. If the path has spaces, keep the English double quotes
   c. -modfolders only accepts the keyword mods, never
      -modfolders="D:\...\mods" -- the game discards it as unknown option

   Close the window; no Steam restart needed. Next launch from that entry
   reads the new saves and mods.

Optional fields: Name (e.g. "PZ Standalone"), Icon.


================================================================
[Check it worked]
================================================================

After launching, look at <new path>\Zomboid\console.txt:
  standalone\Zomboid\mods\xxx paths      -> correct
  unknown option "-modfolders=..."       -> launch options wrong
  workshop\content\108600                -> still reading the Workshop

In the in-game mod panel, any mod on the right:
  Path   = <root>\Zomboid\mods\xxx  -> correct
  Source = Mods                     -> correct


================================================================
[Hard rules]
================================================================

1. Keep the whole standalone folder on one NTFS volume;
   workshop_src cannot be moved to another drive (no cross-volume junctions)
2. Explorer copy turns junctions into real folders and doubles the size.
   Use: robocopy "<old>" "<new>" /E /SL /R:1 /W:1
3. Keep the full path under ~200 characters
4. Do not tick ModLoadOrderSorter_b42, it rewrites default.txt
5. mods\default.txt is the enabled list; if it becomes an empty mods{},
   everything is disabled -- restore it from the Steam copy


================================================================
[FAQ]
================================================================

Q: It says workshop_src not found.
A: Choose Yes and pick it manually; prefer <root>\Zomboid\workshop_src.

Q: "Invalid folder"?
A: The folder has neither numeric workshop-ID\mods structure nor any
   mod folder containing mod.info. Pick another.

Q: Mods still do not load after repair.
A: First check whether mods\default.txt is an empty mods{}; then confirm
   the launch options use -modfolders mods (keyword, not a path).

Q: Fewer junctions than before?
A: Same-name mods keep only one copy (newest wins). The result dialog
   lists what was dropped.

Q: Can I repair junctions only and leave Steam alone?
A: Yes. Junction rebuild and the options file are independent steps;
   if you do not touch Steam it keeps the old path, but the launcher bat
   already works.
