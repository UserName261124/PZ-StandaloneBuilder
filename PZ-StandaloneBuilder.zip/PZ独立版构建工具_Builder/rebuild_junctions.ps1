﻿# 重建 mods 目录联接（修复：含 [ ] 的名字 + 同名按版本择优）
# 用法：pwsh 或 powershell 直接运行

param(
    [Parameter(Mandatory=$false)]
    [string]$Root = "C:\Users\Claymore\Desktop\1"
)

$z    = Join-Path $Root 'Zomboid'
$ws   = Join-Path $z 'workshop_src'
$mods = Join-Path $z 'mods'

if (-not (Test-Path -LiteralPath $ws)) { Write-Host "找不到 $ws"; return }

# ---------- 1. 清掉旧的联接（只删链接，不动真实文件） ----------
$old = Get-ChildItem -LiteralPath $mods -Directory -ErrorAction SilentlyContinue | Where-Object { $_.LinkType -eq 'Junction' }
Write-Host "清理旧联接: $($old.Count) 个"
foreach ($j in $old) {
    try { [System.IO.Directory]::Delete($j.FullName, $false) } catch { Write-Host "清理失败: $($j.Name)" }
}

# ---------- 2. 收集候选 ----------
function Get-ModInfoText {
    param([string]$Dir)
    $candidates = @(
        (Join-Path $Dir 'mod.info'),
        (Join-Path $Dir 'common\mod.info')
    )
    foreach ($c in $candidates) {
        if (Test-Path -LiteralPath $c) { return (Get-Content -LiteralPath $c -Raw -ErrorAction SilentlyContinue) }
    }
    $found = Get-ChildItem -LiteralPath $Dir -Recurse -Depth 2 -Filter 'mod.info' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { return (Get-Content -LiteralPath $found.FullName -Raw -ErrorAction SilentlyContinue) }
    return $null
}

function Parse-Version {
    param([string]$Text, [string]$Key)
    if (-not $Text) { return $null }
    if ($Text -match "(?m)^\s*$Key\s*=\s*([0-9]+(?:\.[0-9]+)*)") {
        try { return [version]$Matches[1] } catch { return $null }
    }
    return $null
}

function Get-Score {
    param([string]$Dir, [string]$WorkshopId)
    $txt = Get-ModInfoText $Dir
    $mv = Parse-Version $txt 'modversion'
    $vm = Parse-Version $txt 'versionMin'
    $id = 0L
    [void][long]::TryParse($WorkshopId, [ref]$id)
    # 排序键：modversion > versionMin > 工坊ID
    if (-not $mv) { $mv = [version]'0.0' }
    if (-not $vm) { $vm = [version]'0.0' }
    return [pscustomobject]@{
        ModVersion = $mv
        VersionMin = $vm
        Id         = $id
    }
}

$candidates = @{}
$wsIds = Get-ChildItem -LiteralPath $ws -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^\d+$' }
foreach ($wsId in $wsIds) {
    $inner = Join-Path $wsId.FullName 'mods'
    if (-not (Test-Path -LiteralPath $inner)) { continue }
    foreach ($d in (Get-ChildItem -LiteralPath $inner -Directory -ErrorAction SilentlyContinue)) {
        $name = $d.Name.Trim()
        if (-not $candidates.ContainsKey($name)) { $candidates[$name] = New-Object System.Collections.ArrayList }
        $s = Get-Score $d.FullName $wsId.Name
        [void]$candidates[$name].Add([pscustomobject]@{
            Name     = $name
            Path     = $d.FullName
            Workshop = $wsId.Name
            ModVersion = $s.ModVersion
            VersionMin = $s.VersionMin
            Id         = $s.Id
        })
    }
}

# ---------- 3. 每个名字择优后建联接 ----------
$created = 0; $skippedList = @(); $failedList = @()
foreach ($name in ($candidates.Keys | Sort-Object)) {
    $list = $candidates[$name]
    $sorted = $list | Sort-Object -Property @{Expression={$_.ModVersion};Descending=$true},
                                          @{Expression={$_.VersionMin};Descending=$true},
                                          @{Expression={$_.Id};Descending=$true}
    $winner = $sorted[0]
    if ($sorted.Count -gt 1) {
        $others = $sorted | Select-Object -Skip 1
        foreach ($o in $others) {
            $skippedList += "同名弃用: $name [保留 $($winner.Workshop) v$($winner.ModVersion)/min$($winner.VersionMin)] 丢弃  $($o.Workshop) v$($o.ModVersion)/min$($o.VersionMin)"
        }
    }
    $link = Join-Path $mods $name
    if (Test-Path -LiteralPath $link) { $skippedList += "目标已存在: $name"; continue }
    # 用 mklink 处理含 [ ] 字面名
    $out = & cmd /c mklink /J "$link" "$($winner.Path)" 2>&1
    if (Test-Path -LiteralPath $link) { $created++ }
    else { $failedList += "$name : $out" }
}

Write-Host ""
Write-Host "创建: $created  跳过: $($skippedList.Count)  失败: $($failedList.Count)"
if ($skippedList.Count) { Write-Host "--- 跳过明细 ---"; $skippedList | ForEach-Object { Write-Host "  $_" } }
if ($failedList.Count)  { Write-Host "--- 失败明细 ---"; $failedList  | ForEach-Object { Write-Host "  $_" } }

# ---------- 4. 校验 ----------
$all = Get-ChildItem -LiteralPath $mods -Directory -ErrorAction SilentlyContinue
$links = $all | Where-Object { $_.LinkType -eq 'Junction' }
$bad = @()
foreach ($d in $links) {
    $has = (Test-Path -LiteralPath (Join-Path $d.FullName 'mod.info')) -or
           (Test-Path -LiteralPath (Join-Path $d.FullName 'common\mod.info')) -or
           (Get-ChildItem -LiteralPath $d.FullName -Recurse -Depth 2 -Filter 'mod.info' -ErrorAction SilentlyContinue | Select-Object -First 1)
    if (-not $has) { $bad += $d.Name }
}
Write-Host ""
Write-Host "联接总数: $($links.Count) ；无 mod.info 的: $($bad.Count)"
if ($bad.Count) { $bad | ForEach-Object { Write-Host "  $_" } }

# ---------- 5. 重建便携启动 bat（%~dp0 自适应路径） ----------
$launcher = @"
@echo off
cd /d "%~dp0ProjectZomboid"
start "" "%~dp0ProjectZomboid\ProjectZomboid64.exe" -agentlib:zbNative=policy=allow-all -- -cachedir="%~dp0Zomboid" -modfolders mods
exit
"@
$launcherCRLF = ($launcher -replace "`r`n","`n") -replace "`n","`r`n"
[System.IO.File]::WriteAllText((Join-Path $Root '启动独立版.bat'), $launcherCRLF, [System.Text.Encoding]::ASCII)
Write-Host ""
Write-Host "已重建 启动独立版.bat（使用 %~dp0 自适应路径，换盘符/换目录可直接用）"
Write-Host "Steam 启动选项请改成新电脑上的实际绝对路径。"

