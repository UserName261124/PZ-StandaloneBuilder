﻿# ============================================================
#  Project Zomboid 独立版构建工具 / Standalone Builder
#  单文件双语：启动时先选语言（中文 / English）
#  Bilingual single script: pick language at launch
# ============================================================

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ---------- 0. 语言选择 / language picker ----------
$script:uiLang = $null
$lf = New-Object System.Windows.Forms.Form
$lf.Text = "选择语言 / Choose language"
$lf.Size = New-Object System.Drawing.Size(380, 185)
$lf.StartPosition = 'CenterScreen'
$lf.FormBorderStyle = 'FixedDialog'
$lf.MaximizeBox = $false
$lf.MinimizeBox = $false
$lf.TopMost = $true

$lbl = New-Object System.Windows.Forms.Label
$lbl.Text = "请选择界面语言 / Select interface language"
$lbl.AutoSize = $true
$lbl.Location = New-Object System.Drawing.Point(38, 28)
$lf.Controls.Add($lbl)

$bZh = New-Object System.Windows.Forms.Button
$bZh.Text = "中文"
$bZh.Size = New-Object System.Drawing.Size(130, 44)
$bZh.Location = New-Object System.Drawing.Point(44, 72)
$bZh.Add_Click({ $script:uiLang = 'zh'; $script:langForm.Close() })
$lf.Controls.Add($bZh)

$bEn = New-Object System.Windows.Forms.Button
$bEn.Text = "English"
$bEn.Size = New-Object System.Drawing.Size(130, 44)
$bEn.Location = New-Object System.Drawing.Point(196, 72)
$bEn.Add_Click({ $script:uiLang = 'en'; $script:langForm.Close() })
$lf.Controls.Add($bEn)

$script:langForm = $lf
$lf.ShowDialog() | Out-Null
if (-not $script:uiLang) { return }
$LANG = $script:uiLang

function L {
    param([string]$zh, [string]$en)
    if ($LANG -eq 'en') { return $en }
    return $zh
}

function PickFolder {
    param([string]$Title, [string]$Initial = "")
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = $Title
    $dlg.ShowNewFolderButton = $true
    if ($Initial -and (Test-Path -LiteralPath $Initial)) { $dlg.SelectedPath = $Initial }
    $r = $dlg.ShowDialog()
    if ($r -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
    return $dlg.SelectedPath
}

function ShowInfo {
    param([string]$Text, [string]$Title)
    if (-not $Title) { $Title = (L "提示" "Notice") }
    [System.Windows.Forms.MessageBox]::Show($Text, $Title,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
}

# ---------- 0.5 进度窗口 / progress window ----------
$script:pf = New-Object System.Windows.Forms.Form
$script:pf.Text = ((L "正在构建" "Building") + " ...")
$script:pf.Size = New-Object System.Drawing.Size(620, 205)
$script:pf.StartPosition = 'CenterScreen'
$script:pf.FormBorderStyle = 'FixedDialog'
$script:pf.ControlBox = $false
$script:pf.TopMost = $true

$script:pLabel = New-Object System.Windows.Forms.Label
$script:pLabel.Text = (L "准备中..." "Preparing...")
$script:pLabel.AutoSize = $false
$script:pLabel.Size = New-Object System.Drawing.Size(570, 44)
$script:pLabel.Location = New-Object System.Drawing.Point(22, 18)
$script:pLabel.Font = New-Object System.Drawing.Font("Microsoft YaHei UI", 10, [System.Drawing.FontStyle]::Bold)
$script:pf.Controls.Add($script:pLabel)

$script:pBar = New-Object System.Windows.Forms.ProgressBar
$script:pBar.Minimum = 0
$script:pBar.Maximum = 100
$script:pBar.Value = 0
$script:pBar.Size = New-Object System.Drawing.Size(520, 26)
$script:pBar.Location = New-Object System.Drawing.Point(22, 78)
$script:pf.Controls.Add($script:pBar)

$script:pPct = New-Object System.Windows.Forms.Label
$script:pPct.Text = "0%"
$script:pPct.AutoSize = $true
$script:pPct.Location = New-Object System.Drawing.Point(556, 82)
$script:pf.Controls.Add($script:pPct)

$script:pSub = New-Object System.Windows.Forms.Label
$script:pSub.Text = ""
$script:pSub.AutoSize = $false
$script:pSub.Size = New-Object System.Drawing.Size(570, 24)
$script:pSub.Location = New-Object System.Drawing.Point(22, 120)
$script:pf.Controls.Add($script:pSub)

function Set-Progress {
    param([int]$Percent, [string]$Text, [string]$Sub)
    if ($Percent -lt 0) { $Percent = 0 }
    if ($Percent -gt 100) { $Percent = 100 }
    $script:pBar.Value = $Percent
    $script:pPct.Text = "$Percent%"
    if ($Text) { $script:pLabel.Text = $Text }
    if ($Sub)  { $script:pSub.Text = $Sub }
    [System.Windows.Forms.Application]::DoEvents()
}

function Close-Progress {
    try { $script:pf.Close(); $script:pf.Dispose() } catch { }
    [System.Windows.Forms.Application]::DoEvents()
}

# ---------- 1. 选择输入路径 / choose input paths ----------
$srcGame = PickFolder (L "① 请选择【Steam 原版游戏目录】（里面要有 ProjectZomboid64.exe）" "1) Select the ORIGINAL Steam game folder (contains ProjectZomboid64.exe)") "D:\Program Files (x86)\Steam\steamapps\common\ProjectZomboid"
if (-not $srcGame) { return }
if (-not (Test-Path -LiteralPath (Join-Path $srcGame 'ProjectZomboid64.exe'))) {
    ShowInfo (L "所选目录里没有 ProjectZomboid64.exe`n请选择包含 ProjectZomboid64.exe 的那一层目录。" "No ProjectZomboid64.exe in the selected folder.`nPick the folder that directly contains ProjectZomboid64.exe.") (L "路径不对" "Wrong folder")
    return
}

$srcWs = PickFolder (L "② 请选择【Steam 创意工坊 108600 目录】" "2) Select the Steam Workshop folder (content\108600)") "D:\Program Files (x86)\Steam\steamapps\workshop\content\108600"
if (-not $srcWs) { return }
if (-not (Test-Path -LiteralPath $srcWs)) { ShowInfo (L "工坊目录不存在。" "Workshop folder does not exist.") (L "路径不对" "Wrong folder"); return }

$srcUser = PickFolder (L "③ 请选择【Steam 用户 Zomboid 配置目录】（存档/模组勾选顺序在这）" "3) Select the Steam user Zomboid folder (saves + mod selection order live here)") "$env:USERPROFILE\Zomboid"

$outRoot = PickFolder (L "④ 请选择【独立版输出根目录】（会在此目录下生成 ProjectZomboid 和 Zomboid）" "4) Select the OUTPUT root folder (ProjectZomboid and Zomboid will be created inside)") ""
if (-not $outRoot) { return }

# ---------- 2. 确认 / confirm ----------
$cfgText = if ($srcUser) { $srcUser } else { (L "(不迁移配置)" "(do not migrate settings)") }
$confirmZh = @"
将执行以下操作：
【输入】
  原版游戏目录 : $srcGame
  工坊108600目录: $srcWs
  用户配置目录 : $cfgText

【输出】
  输出根目录   : $outRoot
  游戏本体     : $outRoot\ProjectZomboid
  数据目录     : $outRoot\Zomboid
  模组目录     : $outRoot\Zomboid\mods
  存档目录     : $outRoot\Zomboid\Saves

流程：复制本体 → 建目录 → 迁移配置/存档/模组顺序 → 复制工坊 mod → 生成 mods 目录联接
复制过程中会显示实时进度条。

请先完全关闭 Project Zomboid 游戏。

继续？
"@
$confirmEn = @"
The following will be done:
[INPUT]
  Original game folder : $srcGame
  Workshop (108600)    : $srcWs
  User config folder   : $cfgText

[OUTPUT]
  Output root          : $outRoot
  Game files           : $outRoot\ProjectZomboid
  Data folder          : $outRoot\Zomboid
  Mods folder          : $outRoot\Zomboid\mods
  Saves folder         : $outRoot\Zomboid\Saves

Steps: copy game -> create folders -> migrate settings/saves/mod order -> copy workshop mods -> build mods junctions
A live progress bar is shown while copying.

Please close Project Zomboid completely first.

Continue?
"@
$confirm = L $confirmZh $confirmEn
$r = [System.Windows.Forms.MessageBox]::Show($confirm, (L "确认执行" "Confirm"),
    [System.Windows.Forms.MessageBoxButtons]::OKCancel,
    [System.Windows.Forms.MessageBoxIcon]::Warning)
if ($r -ne [System.Windows.Forms.DialogResult]::OK) { return }

# ---------- 3. 开始构建 / build ----------
$outGame = Join-Path $outRoot 'ProjectZomboid'
$outZ    = Join-Path $outRoot 'Zomboid'
$outMods = Join-Path $outZ    'mods'
$wsSrc   = Join-Path $outZ    'workshop_src'
$log = New-Object System.Collections.Generic.List[string]
$log.Add("构建时间 / Build time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
$log.Add("输入游戏 / Input game: $srcGame")
$log.Add("输入工坊 / Input workshop: $srcWs")
$log.Add("输入配置 / Input config: $srcUser")
$log.Add("输出根目录 / Output root: $outRoot")

# 带进度复制：统计源目录数，轮询目标目录数换算百分比
# copy with progress: count source dirs, poll destination dir count
function Copy-Tree-WithProgress {
    param([string]$Src, [string]$Dst, [string]$Label, [int]$Base, [int]$Span)
    if (-not (Test-Path -LiteralPath $Src)) { return }
    New-Item -ItemType Directory -Path $Dst -Force | Out-Null

    Set-Progress $Base $Label (L "统计目录数量..." "Counting folders...")
    $totalDirs = 0
    try { $totalDirs = @([System.IO.Directory]::EnumerateDirectories($Src, '*', [System.IO.SearchOption]::AllDirectories)).Count } catch { $totalDirs = 0 }

    $rcLog = Join-Path $env:TEMP ("pz_rc_" + [guid]::NewGuid().ToString('N') + ".log")
    $rcArgs = @(('"' + $Src + '"'), ('"' + $Dst + '"'), '/E', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP', ('/LOG+:"' + $rcLog + '"'))
    $proc = Start-Process -FilePath 'robocopy' -ArgumentList $rcArgs -PassThru -WindowStyle Hidden

    $last = -1
    while (-not $proc.HasExited) {
        $done = 0
        if ($totalDirs -gt 0) {
            try { $done = @([System.IO.Directory]::EnumerateDirectories($Dst, '*', [System.IO.SearchOption]::AllDirectories)).Count } catch { $done = 0 }
        }
        $pct = if ($totalDirs -gt 0) { [int]($Base + ($Span * [math]::Min($done, $totalDirs) / $totalDirs)) } else { $Base }
        if ($pct -ne $last) {
            Set-Progress $pct $Label ("$done / $totalDirs")
            $last = $pct
        }
        Start-Sleep -Milliseconds 700
    }
    Set-Progress ($Base + $Span) $Label (L "完成" "done")
    if (Test-Path -LiteralPath $rcLog) { Remove-Item -LiteralPath $rcLog -Force -ErrorAction SilentlyContinue }
}

# 复制单个目录并排除指定子目录
function Copy-Tree-Excluding {
    param([string]$Src, [string]$Dst, [string[]]$ExcludeDirs)
    New-Item -ItemType Directory -Path $Dst -Force | Out-Null
    $rcArgs = @(('"' + $Src + '"'), ('"' + $Dst + '"'), '/E', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP')
    if ($ExcludeDirs -and $ExcludeDirs.Count -gt 0) { $rcArgs += @('/XD') + $ExcludeDirs }
    & robocopy @rcArgs | Out-Null
}

$script:pf.Show()
[System.Windows.Forms.Application]::DoEvents()

# 第 1 步：复制游戏本体 0-45%
$step1 = L "[1/5] 复制游戏本体" "[1/5] Copying game files"
Copy-Tree-WithProgress $srcGame $outGame $step1 0 45

# 第 2 步：建目录 45-47%
Set-Progress 45 (L "[2/5] 创建目录结构" "[2/5] Creating folder structure") ""
foreach ($sub in @('mods','Saves','Configs','Sandbox Presets','Lua','Server','workshop_src','Logs')) {
    New-Item -ItemType Directory -Path (Join-Path $outZ $sub) -Force | Out-Null
}
Set-Progress 47 (L "[2/5] 目录结构完成" "[2/5] Folder structure ready") ""

# 第 3 步：迁移配置 47-55%
$step3 = L "[3/5] 迁移配置 / 存档 / 模组顺序" "[3/5] Migrating settings / saves / mod order"
Set-Progress 47 $step3 (L "复制配置与存档..." "Copying settings and saves...")
if ($srcUser -and (Test-Path -LiteralPath $srcUser)) {
    Copy-Tree-Excluding $srcUser $outZ @('mods','Logs','Workshop','workshop_src')
    $log.Add("已迁移配置 / Settings migrated: options.ini, InputBindings, Configs, Saves")

    $srcDefault = Join-Path $srcUser 'mods\default.txt'
    if (Test-Path -LiteralPath $srcDefault) {
        $dstDefault = Join-Path $outMods 'default.txt'
        if (Test-Path -LiteralPath $dstDefault) {
            Copy-Item -LiteralPath $dstDefault -Destination (Join-Path $outMods 'default_old.txt') -Force
        }
        Copy-Item -LiteralPath $srcDefault -Destination $dstDefault -Force
        $log.Add("已迁移模组勾选与顺序 / Mod selection and load order migrated: default.txt")
    } else {
        $log.Add("未找到 default.txt / default.txt not found")
    }
} else {
    $log.Add("未迁移用户配置 / User config not migrated")
}
Set-Progress 55 $step3 (L "完成" "done")

# 第 4 步：复制工坊包 55-90%
$step4 = L "[4/5] 复制工坊 mod 原始包" "[4/5] Copying workshop packages"
Copy-Tree-WithProgress $srcWs $wsSrc $step4 55 35

# 第 5 步：生成联接 90-100%
$step5 = L "[5/5] 生成 mods 目录联接" "[5/5] Creating mods junctions"
Set-Progress 90 $step5 (L "扫描模组..." "Scanning mods...")

function Get-ModInfoText {
    param([string]$Dir)
    foreach ($c in @((Join-Path $Dir 'mod.info'), (Join-Path $Dir 'common\mod.info'))) {
        if (Test-Path -LiteralPath $c) { return (Get-Content -LiteralPath $c -Raw -ErrorAction SilentlyContinue) }
    }
    $found = Get-ChildItem -LiteralPath $Dir -Recurse -Depth 2 -Filter 'mod.info' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { return (Get-Content -LiteralPath $found.FullName -Raw -ErrorAction SilentlyContinue) }
    return $null
}

function Parse-Ver {
    param([string]$Text, [string]$Key)
    if (-not $Text) { return $null }
    if ($Text -match "(?m)^\s*$Key\s*=\s*([0-9]+(?:\.[0-9]+)*)") {
        try { return [version]$Matches[1] } catch { return $null }
    }
    return $null
}

$created = 0; $skipped = @(); $failed = @()

$candidates = @{}
$wsIds = @(Get-ChildItem -LiteralPath $wsSrc -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^\d+$' })
foreach ($id in $wsIds) {
    $inner = Join-Path $id.FullName 'mods'
    if (-not (Test-Path -LiteralPath $inner)) { continue }
    foreach ($d in (Get-ChildItem -LiteralPath $inner -Directory -ErrorAction SilentlyContinue)) {
        $name = $d.Name.Trim()
        if (-not $candidates.ContainsKey($name)) { $candidates[$name] = New-Object System.Collections.ArrayList }
        $txt = Get-ModInfoText $d.FullName
        $mv = Parse-Ver $txt 'modversion'; if (-not $mv) { $mv = [version]'0.0' }
        $vm = Parse-Ver $txt 'versionMin'; if (-not $vm) { $vm = [version]'0.0' }
        $wid = 0L; [void][long]::TryParse($id.Name, [ref]$wid)
        [void]$candidates[$name].Add([pscustomobject]@{
            Path = $d.FullName; Workshop = $id.Name
            ModVersion = $mv; VersionMin = $vm; Id = $wid
        })
    }
}

$names = @($candidates.Keys | Sort-Object)
$n = 0
foreach ($name in $names) {
    $n++
    $sorted = $candidates[$name] | Sort-Object -Property @{Expression={$_.ModVersion};Descending=$true},
                                                      @{Expression={$_.VersionMin};Descending=$true},
                                                      @{Expression={$_.Id};Descending=$true}
    $winner = $sorted[0]
    if ($sorted.Count -gt 1) {
        foreach ($o in ($sorted | Select-Object -Skip 1)) {
            $skipped += ("$name : 保留/kept ws$($winner.Workshop) v$($winner.ModVersion) ; 丢弃/dropped ws$($o.Workshop) v$($o.ModVersion)")
        }
    }
    $link = Join-Path $outMods $name
    if (Test-Path -LiteralPath $link) { $skipped += ("$name : 目标已存在 / target exists"); continue }
    $null = & cmd /c mklink /J "$link" "$($winner.Path)" 2>&1
    if (Test-Path -LiteralPath $link) { $created++ } else { $failed += "$name : mklink failed" }

    if ($names.Count -gt 0) {
        $pct = 90 + [int](9 * $n / $names.Count)
        Set-Progress $pct $step5 ("$n / $($names.Count)")
    }
}

$log.Add("联接 / Junctions: 新建/created $created ; 跳过/skipped $($skipped.Count) ; 失败/failed $($failed.Count)")
foreach ($s in $skipped) { $log.Add("跳过 / skip -> $s") }
foreach ($f in $failed)  { $log.Add("失败 / fail -> $f") }

# ---------- 4. 生成启动 bat 与说明 / launcher + readme ----------
Set-Progress 100 (L "生成启动文件与说明" "Writing launcher and read me") ""
# 用 %~dp0 相对自身位置，整个文件夹搬到任何盘任何路径都能直接双击运行
$launcher = @"
@echo off
cd /d "%~dp0ProjectZomboid"
start "" "%~dp0ProjectZomboid\ProjectZomboid64.exe" -agentlib:zbNative=policy=allow-all -- -cachedir="%~dp0Zomboid" -modfolders mods
exit
"@
$launcherCRLF = ($launcher -replace "`r`n","`n") -replace "`n","`r`n"
[System.IO.File]::WriteAllText((Join-Path $outRoot '启动独立版_Start.bat'), $launcherCRLF, [System.Text.Encoding]::ASCII)

# 说明里不写死用户名：用户目录整体替换为占位符
$prof = $env:USERPROFILE
$mz = $outRoot
$me = $outRoot
if ($prof) {
    $mz = $outRoot -replace [regex]::Escape($prof), 'C:\Users\你的用户名'
    $me = $outRoot -replace [regex]::Escape($prof), 'C:\Users\YourName'
}

$readme = @"
============================================================
Project Zomboid 独立版 启动说明 / Standalone Edition - Read Me
============================================================

[中文]

一、Steam 添加非 Steam 游戏
  目标     : $mz\ProjectZomboid\ProjectZomboid64.exe
  起始位置 : $mz\ProjectZomboid
  启动选项 : -agentlib:zbNative=policy=allow-all -- -cachedir="$mz\Zomboid" -modfolders mods

二、目录说明
  游戏本体 : $mz\ProjectZomboid
  数据目录 : $mz\Zomboid
  模组目录 : $mz\Zomboid\mods
  存档目录 : $mz\Zomboid\Saves
  工坊原包 : $mz\Zomboid\workshop_src   （不能改名、不能移动，否则 mods 里的联接全部失效）

三、要点
  - 只读取 $mz\Zomboid\mods，不访问 Steam 创意工坊目录
  - 保留 Steam 联机（未使用 -nosteam）
  - 模组清单与加载顺序来自 Steam 原版 default.txt
  - 不要勾选 ModLoadOrderSorter_b42，否则会重写加载顺序
  - 本副本不受 Steam 本体更新影响
  - mods 下的联接个数取决于本机备份的模组规模，不固定

四、迁移到其他电脑（重要）
  - 完整复制整个 $mz 文件夹
  - 复制或移动完成后，务必先运行 隔壁 PZ独立版迁移工具\迁移修复_Repair.bat
    重建 mods 目录联接，否则 mods 全部变成死链，
    原版 Steam 版本也会读不到这些模组
  - 新电脑上启动选项里的 -cachedir 改成新实际路径
  - 若换了硬盘分区，同样需要重建联接

五、本目录产物
  启动独立版_Start.bat  双击直接启动（便携，换路径也能用）
  使用说明_ReadMe.txt    本文件（中英双语）
  构建日志_BuildLog.txt  构建过程记录（中英双语）

============================================================

[English]

1. Add as a non-Steam game in Steam
   Target     : $me\ProjectZomboid\ProjectZomboid64.exe
   Start In   : $me\ProjectZomboid
   Launch Opts: -agentlib:zbNative=policy=allow-all -- -cachedir="$me\Zomboid" -modfolders mods

2. Folders
   Game files     : $me\ProjectZomboid
   Data (cachedir): $me\Zomboid
   Mods           : $me\Zomboid\mods
   Saves          : $me\Zomboid\Saves
   Workshop source: $me\Zomboid\workshop_src  (do not rename or move, or all mods junctions break)

3. Key points
  - The game only reads $me\Zomboid\mods, never the Steam Workshop folder
  - Steam multiplayer is kept (no -nosteam)
  - Mod list and load order come from the original Steam default.txt
  - Do not tick ModLoadOrderSorter_b42, it rewrites the load order
  - This copy is not affected by Steam game updates
  - The number of junctions depends on how many mods were backed up here; it is not fixed

4. Moving to another PC (important)
  - Copy the whole $me folder
  - After copying, ALWAYS run the migration repair tool first
    (PZ独立版迁移工具\迁移修复_Repair.bat) to rebuild the mods junctions.
    Otherwise every junction becomes a dead link, and even the original
    Steam installation cannot load these mods any more.
  - Change -cachedir in the Steam launch options to the new real path
  - A new drive or partition also requires rebuilding the junctions

5. Files in this folder
   startup bat          double-click to play (portable, works after moving)
   read me (bilingual)  this file
   build log (bilingual) build record

注 / Note: 路径里的占位符请替换成实际值 / replace the placeholder with your real values.
"@
Set-Content -LiteralPath (Join-Path $outRoot '使用说明_ReadMe.txt') -Value $readme -Encoding UTF8
$log | Set-Content -LiteralPath (Join-Path $outRoot '构建日志_BuildLog.txt') -Encoding UTF8

$doneZh = @"
构建完成

游戏本体：$outGame
数据目录：$outZ
模组目录：$outMods
存档目录：$outZ\Saves

mod 联接：新建 $created 个，跳过 $($skipped.Count) 个，失败 $($failed.Count) 个

已生成：
  启动独立版_Start.bat
  使用说明_ReadMe.txt
  构建日志_BuildLog.txt

可以直接双击启动，或在 Steam 里添加该 exe 并填入启动选项。

【重要】如果要把这个文件夹复制、移动到别的位置或别的电脑，
复制完成后必须先运行隔壁 PZ独立版迁移工具\迁移修复_Repair.bat 重建 mods 联接。
否则 mods 里的联接全部失效，原版 Steam 版本也会加载不到这些模组。
"@
$doneEn = @"
Build complete

Game files : $outGame
Data folder: $outZ
Mods folder: $outMods
Saves      : $outZ\Saves

Junctions: created $created, skipped $($skipped.Count), failed $($failed.Count)

Generated:
  启动独立版_Start.bat (startup bat)
  使用说明_ReadMe.txt  (bilingual read me)
  构建日志_BuildLog.txt (bilingual build log)

Double-click the startup bat to play, or add the exe to Steam with the launch options.

[IMPORTANT] If you copy or move this folder to another location or PC,
you MUST run the migration repair tool first
(PZ独立版迁移工具\迁移修复_Repair.bat) to rebuild the mods junctions.
Otherwise all junctions become dead links and even the original Steam
installation will fail to load these mods.
"@
Close-Progress
ShowInfo (L $doneZh $doneEn) (L "构建完成" "Build complete")
