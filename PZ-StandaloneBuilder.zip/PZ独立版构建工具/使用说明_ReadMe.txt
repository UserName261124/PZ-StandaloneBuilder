﻿================================================================
        Project Zomboid 独立版构建工具  使用说明
================================================================

【这套工具干什么】

把你 Steam 上的《僵尸毁灭工程》复制成一套完全独立的运行环境：
游戏本体、模组、存档、全部设置文件都收进一个文件夹里，
只读自己目录下的模组，不再受 Steam 本体更新和创意工坊更新影响，
同时保留 Steam 联机。


================================================================
【文件夹内容】
================================================================

  双击运行_Run.bat        入口，双击后先选语言（中文 / English），再走构建流程
  builder.ps1           实际执行的构建脚本（单文件双语，由 bat 调用）
  rebuild_junctions.ps1 只重建 mods 目录联接 + 重写便携启动 bat
  使用说明_ReadMe.txt     本文档（中文在前，英文见下文 [English] 一节）

  迁移工具已独立到隔壁文件夹：PZ独立版迁移工具\


================================================================
【使用步骤】
================================================================

1. 关闭游戏
   任务管理器确认没有 ProjectZomboid64.exe 进程。
   游戏运行时写存档、options.ini 和模组顺序文件，
   边跑边复制会损坏数据。

2. 双击 双击运行_Run.bat，先弹一个小窗选语言（中文 / English）
   选定后依次弹出 4 个文件夹选择框：

   (1) Steam 原版游戏目录
       选到包含 ProjectZomboid64.exe 的那一层，一般是：
       X:\Steam\steamapps\common\ProjectZomboid
       选错（选到上层 common 或下层 media）脚本会提示并退出。

   (2) Steam 创意工坊 108600 目录
       一般是：
       X:\Steam\steamapps\workshop\content\108600
       里面全是纯数字的工坊 ID 文件夹。

   (3) Steam 用户配置目录
       默认 C:\Users\你的用户名\Zomboid
       存档、设置、按键绑定、模组勾选和加载顺序都在这。
       取消选择则只复制游戏本体和模组，不迁移配置。

   (4) 输出根目录
       你自己定，建议放在空间充足的非系统盘。
       脚本会在该目录下生成：

       输出目录\
       ├─ ProjectZomboid\      游戏本体
       └─ Zomboid\             数据目录（cachedir）
          ├─ mods\             模组（全是 junction 联接）
          ├─ Saves\            存档
          ├─ InputBindings\    按键绑定
          ├─ options.ini       显示/音量/游戏选项
          ├─ Configs\          其他设置
          ├─ workshop_src\     工坊原始包（真正的文件在这）
          └─ Logs\             日志

3. 确认后自动构建
   弹窗会列出全部路径，点确定才开始。构建期间会弹出一个进度窗口：
   进度条 + 百分比 + 当前阶段 + 已复制/总目录数，实时刷新。
   本体和工坊包都是几十 GB、几十万文件，复制过程需要耐心等它跑完。

   执行五步：
   (1) 复制游戏本体
   (2) 创建目录结构
   (3) 迁移整个用户配置目录
       —— 注意：是“整目录搬迁”，不是只挑几个子文件夹。
          除 mods、Logs、Workshop、workshop_src 之外，
          根级 options.ini、InputBindings、latestSave.ini、
          viewpoint-* 等全部一起搬过来。
          少搬这些，就会出现“按键设置、显示设置全没了”。
   (4) 复制工坊原始包到 workshop_src
   (5) 在 mods 里批量生成 junction 联接
       —— 用 mklink /J 创建，所以文件夹名里带 [ ] 也能正常建；
          同一模组名在多个工坊包里出现时，按
          modversion → versionMin → 工坊ID 依次比较，保留最新版

   构建完成后自动生成三个文件到输出根目录：
   启动独立版_Start.bat      便携启动器（双击即启动）
   使用说明_ReadMe.txt       本说明（中英双语）
   构建日志_BuildLog.txt     构建过程记录（中英双语，含每个跳过/失败的模组）

   【重要提醒】构建完成后弹窗会再次强调：
   只要把这个文件夹复制、移动到别的位置或别的电脑，
   就必须先运行 隔壁 PZ独立版迁移工具\迁移修复_Repair.bat 重建 mods 联接。
   否则 mods 里的联接全部变成死链，原版 Steam 版本也会加载不到这些模组。

4. 启动
   两种方式任选：

   A. 直接双击输出目录下的 启动独立版_Start.bat

   B. 在 Steam 里添加非 Steam 游戏（推荐，能联机、能用好友邀请）
      目标     : 输出目录\ProjectZomboid\ProjectZomboid64.exe
      起始位置 : 输出目录\ProjectZomboid
      启动选项 :
      -agentlib:zbNative=policy=allow-all -- -cachedir="输出目录\Zomboid" -modfolders mods

      注意：-cachedir 必须是绝对路径，带空格要保留引号。
      注意：-modfolders mods 只能写关键字 mods，不能写磁盘路径，
            写路径会被当成 unknown option 直接丢弃。


================================================================
【原理】
================================================================

本体独立：本体是复制出来的副本，Steam 不认识它，不会随原版自动更新
模组独立：-modfolders mods 让游戏只扫描 <cachedir>\mods，
          完全不访问 Steam 工坊目录
顺序一致：mods\default.txt 记录模组勾选状态和加载顺序，从 Steam 版原样迁移
不重复占空间：工坊包留在 workshop_src，mods 里只放目录联接（junction），零额外占用
联机可用：没有加 -nosteam，Steam 联机功能正常


================================================================
【验证是否成功】
================================================================

进游戏后打开模组面板，任选一个模组看右侧信息：

  Path     : 输出目录\Zomboid\mods\xxx     -> 正确
  Source   : Mods                          -> 正确
  若显示 Steam 网页链接、Source: Steam    -> 还在读工坊，参数没生效

也可以看日志 <cachedir>\console.txt：

  出现 Zomboid\mods\ 路径，且搜索不到 workshop\content  -> 成功
  出现 unknown option "-modfolders=..."                 -> 参数写错，
                                                            用了 = 加磁盘路径

设置是否迁移成功，看 <cachedir> 根目录：
  有 options.ini（字节数和源一致）、有 InputBindings 目录 -> 成功


================================================================
【硬性注意事项】
================================================================

1. workshop_src 不能改名、不能移动，否则 mods 里所有联接失效
2. 不要勾选 ModLoadOrderSorter_b42，它会在启动时自动重排并覆盖 default.txt
3. mods\default.txt 是加载顺序的唯一依据，游戏启动/退出时可能重写。
   特别注意：如果某次启动时模组没被扫到，游戏会把 default.txt
   写成空的 mods{}，之后就一直“全部模组未启用”。
   所以调好顺序后务必自己备份一份。
4. 备份要整个输出目录一起打包，只备份 mods 会把联接当实体复制，体积翻倍
5. junction 依赖 NTFS 同分区，跨分区创建会失败
6. 运行前游戏必须完全退出，两个实例同时跑会互相锁文件


================================================================
【单独重建联接】
================================================================

改错联接、或换了分区时，不用重跑整个构建，直接：

  powershell -ExecutionPolicy Bypass -File rebuild_junctions.ps1 -Root "输出根目录"

它会先删掉 mods 里现有的全部联接（只删链接，不动真实文件），
再按同样的“版本择优 + mklink”规则重新生成，并输出校验结果。


================================================================
【迁移到其他电脑】
================================================================

能不能直接跑？分项说明：

  游戏本体        能。本体只读自己所在目录，换盘换路径都不影响
  存档 / 设置     能。都在 Zomboid 目录里，跟着文件夹走
  mod 实体文件    能。都在 Zomboid\workshop_src 里
  mods 目录联接  不能直接用。联接记录的是绝对路径，盘符或目录一变
                 就全部变成死链。文件不会丢，重建即可
  启动独立版_Start.bat  新版已用 %~dp0 自适应，搬过去直接双击可用
                 （旧版写死绝对路径的，用隔壁 PZ独立版迁移工具\迁移修复_Repair.bat 重建）
  Steam 启动选项 不能直接沿用。里面的 -cachedir 写的是旧电脑路径，
                 要在新电脑改成实际路径

操作顺序：

1. 旧电脑：完全退出游戏
2. 复制整个输出目录到新电脑
   —— 用资源管理器直接复制也行，但注意：联接会被当成普通文件夹
      把内容复制一遍，体积会翻倍（约多出工坊包的大小）。
      想省时间就用 robocopy /E /SL，联接会按链接复制：
      robocopy "旧目录" "新目录" /E /SL /R:1 /W:1
3. 新电脑：双击隔壁 PZ独立版迁移工具\迁移修复_Repair.bat，选择新位置的输出根目录
   它会：
     - 删掉失效的 mods 联接（只删链接，不动 workshop_src 里的文件）
     - 按 版本择优 + mklink 重新生成全部联接
     - 重写 启动独立版_Start.bat（%~dp0 自适应路径）
4. Steam 添加非 Steam 游戏，启动选项改成新电脑实际路径：
   -agentlib:zbNative=policy=allow-all -- -cachedir="新路径\Zomboid" -modfolders mods
5. 新电脑同样不要勾选 ModLoadOrderSorter_b42

限制条件：
  - 新电脑磁盘必须是 NTFS（junction 不支持 FAT32 / exFAT）
  - 整个文件夹必须放在同一个分区里，不能把 workshop_src 拆到别的盘
  - 复制后的完整路径不要过长，建议控制在 200 字符以内
    （路径太长会让 Java 读不到深层文件）
  - 不需要重装 Steam 本体，也不用重新下载模组

注意：迁移后存档路径会变， multiplayer 联机时对方必须和你
      本体版本、mod 版本完全一致。


================================================================
【常见问题】
================================================================

问：按键设置、显示设置全没了？
答：cachedir 根级的 options.ini 和 InputBindings 没迁过来。
    用旧版脚本会出现这个情况，把源目录整个搬一遍即可（新脚本已修正）。

问：模组列表一片空白？
答：先看 mods\default.txt 是不是空的 mods{}。
    如果是，说明上次启动没扫到模组却把空清单存了回去，
    用 Steam 版原文件覆盖它即可。
    再检查 mods 下是否为 mod 名文件夹，且文件夹里有 mod.info
    （或 common\mod.info）。工坊原始包结构是 工坊ID\mods\模组名，
    直接丢进 mods 是识别不到的，必须靠联接。

问：联接创建报“找不到路径”，名字里带 [ ]？
答：PowerShell 的 New-Item -Path 会把 [ ] 当通配符。
    新版脚本已改用 mklink /J，可以正常创建。

问：面板显示 Source: Steam？
答：启动参数没生效。确认 -modfolders mods 在 -- 后面，
    且没有写成 -modfolders=路径。

问：加载顺序被改了？
答：ModLoadOrderSorter_b42 在作怪，取消勾选；
    或把备份的 default.txt 覆盖回去。

问：字体报错 AngelCodeFont failed to load page？
答：B42 原版自带的告警，与模组无关，可忽略。


================================================================
        Project Zomboid Standalone Builder - Instructions (EN)
================================================================

[Language] The script is bilingual: double-click 双击运行_Run.bat, a small
window asks 中文 / English, everything after that (folder dialogs,
confirmations, result dialogs, generated read me) follows your choice.
One script, no separate English copy to maintain.


[What this tool does]

Turns your Steam copy of Project Zomboid into a fully standalone
environment: game files, mods, saves and every settings file live
inside one folder. The game reads mods only from its own folder,
so neither Steam game updates nor Workshop updates can touch it,
while Steam multiplayer still works.


================================================================
[Folder contents]
================================================================

  双击运行_Run.bat         entry point; double-click to start, then pick a language
  builder.ps1           the actual build script (bilingual, called by the bat)
  rebuild_junctions.ps1 rebuilds mods junctions + rewrites the portable launcher
  使用说明_ReadMe.txt      this document (Chinese first, English below)
  (the migration tool lives in its own folder, see the end of this file)


================================================================
[Steps]
================================================================

1. Close the game
   Make sure no ProjectZomboid64.exe is running in Task Manager.
   The game writes saves, options.ini and the mod order file while
   running; copying them mid-game corrupts them.

2. Double-click 双击运行_Run.bat, choose 中文 or English
   Four folder dialogs appear in order:

   (1) Original Steam game folder
       The level that directly contains ProjectZomboid64.exe, usually:
       X:\Steam\steamapps\common\ProjectZomboid
       Picking the wrong level makes the script stop with a warning.

   (2) Steam Workshop folder 108600
       Usually:
       X:\Steam\steamapps\workshop\content\108600
       It contains numeric workshop-ID folders only.

   (3) Steam user config folder
       Default: C:\Users\<your name>\Zomboid
       Saves, options, keybinds, mod selection and load order all live here.
       Cancel this dialog to copy only the game and mods, no settings.

   (4) Output root folder
       Your choice; a roomy non-system drive is recommended.
       The script creates:

       <output>\
       |- ProjectZomboid\      game files
       |- Zomboid\             data folder (cachedir)
          |- mods\             mods (all junctions)
          |- Saves\            saves
          |- InputBindings\    keybinds
          |- options.ini       display / audio / gameplay options
          |- Configs\          other settings
          |- workshop_src\     original workshop packages (real files here)
          '- Logs\             logs

3. Confirm and build
   A dialog lists every path; clicking OK opens a progress window:
   progress bar + percentage + current stage + copied/total folders, live.
   The game and Workshop packages are tens of GB and hundreds of thousands
   of files, so let it run to the end.

   Five steps:
   (1) copy game files
   (2) create the folder structure
   (3) migrate the WHOLE user config folder
       -- not just a few subfolders. Everything except mods, Logs,
          Workshop and workshop_src is copied, including root-level
          options.ini, InputBindings, latestSave.ini, viewpoint-* etc.
          Skipping those is exactly what causes "all my keybinds and
          display settings are gone".
   (4) copy workshop packages into workshop_src
   (5) create junctions in mods
       -- created with mklink /J, so folder names containing [ ] work;
          when the same mod name appears in several workshop packages,
          modversion then versionMin then workshop ID are compared
          and the newest wins

   Three files are generated in the output root:
   启动独立版_Start.bat  - portable launcher
   使用说明_ReadMe.txt    - this read me (bilingual)
   构建日志_BuildLog.txt  - build log (bilingual, lists every skipped/failed mod)

   [IMPORTANT] The completion dialog repeats this warning:
   whenever you copy or move this folder to another location or PC,
   you MUST first run the migration repair tool
   (PZ独立版迁移工具\迁移修复_Repair.bat) to rebuild the mods junctions.
   Otherwise all junctions become dead links and even the original Steam
   installation cannot load these mods.

4. Launch, either way

   A. Double-click the generated 启动独立版_Start.bat

   B. Add as a non-Steam game in Steam (recommended: multiplayer works)
       Target     : <output>\ProjectZomboid\ProjectZomboid64.exe
       Start In   : <output>\ProjectZomboid
       Launch Opts:
       -agentlib:zbNative=policy=allow-all -- -cachedir="<output>\Zomboid" -modfolders mods

       -cachedir must be an absolute path; keep the quotes if it has spaces.
       -modfolders only accepts the keyword mods, never a disk path --
       a path there is discarded as "unknown option".


================================================================
[How it works]
================================================================

Game independent   : it is a copy; Steam does not track it and never updates it
Mods independent   : -modfolders mods makes the game scan only <cachedir>\mods
Order preserved    : mods\default.txt holds selection + load order, copied from the Steam install
No extra disk cost : workshop packages stay in workshop_src, mods holds junctions only
Multiplayer works  : no -nosteam was used, Steam features stay intact


================================================================
[Verify it worked]
================================================================

In game, open the mod panel and check any mod on the right:

  Path   : <output>\Zomboid\mods\xxx      -> correct
  Source : Mods                           -> correct
  Steam web link / Source: Steam          -> still reading the Workshop

Also check the log <cachedir>\console.txt:

  Zomboid\mods\ paths present, no workshop\content -> success
  unknown option "-modfolders=..."                 -> wrong parameter
                                                      (used "=" plus a path)

Settings migrated? Look at the <cachedir> root:
  options.ini exists (same byte size as source) and InputBindings exists -> success


================================================================
[Hard rules]
================================================================

1. workshop_src must not be renamed or moved, or every junction breaks
2. Do not tick ModLoadOrderSorter_b42; it rewrites default.txt at startup
3. mods\default.txt is the single source of load order, and the game may
   rewrite it on start/exit. If one launch fails to scan mods, the game
   can save it as an empty mods{} and everything stays disabled. Back it
   up once your order is right.
4. Back up the whole output folder at once; backing up mods alone copies
   junctions as real folders and doubles the size
5. Junctions need NTFS on the same volume; cross-volume creation fails
6. The game must be fully closed first; two instances lock each other's files


================================================================
[Rebuild junctions only]
================================================================

If the junctions are wrong or the drive changed, no need to rebuild everything:

  powershell -ExecutionPolicy Bypass -File rebuild_junctions.ps1 -Root "<output root>"

It deletes all existing junctions (links only, real files untouched),
recreates them with the same version preference + mklink rule,
and prints the verification result.


================================================================
[Moving to another PC]
================================================================

What survives a copy:

  Game files        yes - reads only its own folder, any path works
  Saves / settings  yes - inside the Zomboid folder, travels with it
  Mod real files    yes - inside Zomboid\workshop_src
  mods junctions    no  - they store absolute paths; a new drive letter
                          or path turns them into dead links. Files are
                          fine, just rebuild them
  launcher bat      yes - the new one uses %~dp0 and works anywhere
  Steam options     no  - -cachedir points at the old machine; update it

Order of operations:

1. Old PC: fully close the game
2. Copy the whole output folder
   Explorer copy works but treats junctions as real folders and duplicates
   the workshop payload. To save time use robocopy /E /SL:
       robocopy "<old>" "<new>" /E /SL /R:1 /W:1
3. New PC: run the migration repair tool (separate folder), pick the new root
   It deletes dead junctions, rebuilds them by version preference,
   and rewrites the portable launcher
4. Steam: add the non-Steam game, launch options using the new real path:
   -agentlib:zbNative=policy=allow-all -- -cachedir="<new>\Zomboid" -modfolders mods
5. Do not tick ModLoadOrderSorter_b42 on the new machine either

Limits:
  - NTFS required (no FAT32 / exFAT)
  - keep the whole folder on one volume; do not split workshop_src to another drive
  - keep the full path under ~200 characters, or Java cannot open deep files
  - no need to reinstall Steam or re-download mods

Note: after moving, save paths change; for multiplayer everyone must run
      the same game version and the same mod versions.


================================================================
[FAQ]
================================================================

Q: All keybinds and display settings are gone.
A: Root-level options.ini and InputBindings were not migrated. Older
   scripts did that; migrating the whole source folder fixes it.

Q: The mod list is completely empty.
A: Check whether mods\default.txt is an empty mods{}. If so, a launch
   scanned nothing and saved the empty list back; overwrite it with the
   Steam copy. Then confirm mods contains mod-name folders holding
   mod.info (or common\mod.info). Workshop packages are
   workshop-ID\mods\mod-name, so they cannot be dropped in directly -
   that is what junctions are for.

Q: "Path not found" when creating junctions, names with [ ]?
A: New-Item -Path treats [ ] as wildcards. The current script uses
   mklink /J instead and handles them.

Q: The panel shows Source: Steam.
A: Launch options are not applied. Make sure -modfolders mods sits after
   -- and is not written as -modfolders=<path>.

Q: The load order changed by itself.
A: ModLoadOrderSorter_b42 did it; untick it or restore your default.txt.

Q: AngelCodeFont failed to load page?
A: A stock B42 warning, unrelated to mods; ignore it.


================================================================
[Related: migration tool]
================================================================

Migration lives in its own folder next to this one:
  PZ独立版迁移工具\ 迁移修复_Repair.bat  migrate.ps1  使用说明_ReadMe.txt
Use it after copying the standalone folder to a new location or PC.
