﻿# ============================================================
#  Project Zomboid 独立版 —— 迁移修复工具 / Migration Repair
#  单文件双语：启动时先选语言（中文 / English）
#  Bilingual single script: pick language at launch
# ============================================================

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ---------- 0. 语言选择 / language picker ----------
$script:uiLang = $null
$lf = New-Object System.Windows.Forms.Form
$lf.Text = "选择语言 / Choose language"
$lf.Size = New-Object System.Drawing.Size(380, 185)
$lf.StartPosition = 'CenterScreen'
$lf.FormBorderStyle = 'FixedDialog'
$lf.MaximizeBox = $false
$lf.MinimizeBox = $false
$lf.TopMost = $true

$lbl = New-Object System.Windows.Forms.Label
$lbl.Text = "请选择界面语言 / Select interface language"
$lbl.AutoSize = $true
$lbl.Location = New-Object System.Drawing.Point(38, 28)
$lf.Controls.Add($lbl)

$bZh = New-Object System.Windows.Forms.Button
$bZh.Text = "中文"
$bZh.Size = New-Object System.Drawing.Size(130, 44)
$bZh.Location = New-Object System.Drawing.Point(44, 72)
$bZh.Add_Click({ $script:uiLang = 'zh'; $script:langForm.Close() })
$lf.Controls.Add($bZh)

$bEn = New-Object System.Windows.Forms.Button
$bEn.Text = "English"
$bEn.Size = New-Object System.Drawing.Size(130, 44)
$bEn.Location = New-Object System.Drawing.Point(196, 72)
$bEn.Add_Click({ $script:uiLang = 'en'; $script:langForm.Close() })
$lf.Controls.Add($bEn)

$script:langForm = $lf
$lf.ShowDialog() | Out-Null
if (-not $script:uiLang) { return }
$LANG = $script:uiLang

function L {
    param([string]$zh, [string]$en)
    if ($LANG -eq 'en') { return $en }
    return $zh
}

function PickFolder {
    param([string]$Title, [string]$Initial = "")
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = $Title
    $dlg.ShowNewFolderButton = $true
    if ($Initial -and (Test-Path -LiteralPath $Initial)) { $dlg.SelectedPath = $Initial }
    $r = $dlg.ShowDialog()
    if ($r -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
    return $dlg.SelectedPath
}

function ShowInfo {
    param([string]$Text, [string]$Title)
    if (-not $Title) { $Title = (L "提示" "Notice") }
    [System.Windows.Forms.MessageBox]::Show($Text, $Title,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
}

function AskYesNo {
    param([string]$Text, [string]$Title)
    if (-not $Title) { $Title = (L "确认" "Confirm") }
    $r = [System.Windows.Forms.MessageBox]::Show($Text, $Title,
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question)
    return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
}

# ---------- 1. 选独立版根目录 / pick standalone root ----------
$root = PickFolder (L "① 请选择独立版根目录（里面要有 ProjectZomboid 和 Zomboid 两个文件夹）" "1) Select the standalone root folder (must contain ProjectZomboid and Zomboid)")
if (-not $root) { return }

$z    = Join-Path $root 'Zomboid'
$mods = Join-Path $z 'mods'
$game = Join-Path $root 'ProjectZomboid'

if (-not (Test-Path -LiteralPath $z)) {
    ShowInfo (L "所选目录里没有 Zomboid 文件夹`n请选择独立版根目录（与 ProjectZomboid 同级的那层）。" "No Zomboid folder here.`nPick the standalone root (the level that also contains ProjectZomboid).") (L "路径不对" "Wrong folder")
    return
}
if (-not (Test-Path -LiteralPath $mods)) {
    New-Item -ItemType Directory -Path $mods -Force | Out-Null
}

# ---------- 2. 定位工坊原始包 / locate workshop source ----------
function Test-WorkshopRoot {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $ids = Get-ChildItem -LiteralPath $Path -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^\d+$' -and (Test-Path -LiteralPath (Join-Path $_.FullName 'mods')) }
    return ($ids.Count -gt 0)
}

function Test-FlatModRoot {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $hit = Get-ChildItem -LiteralPath $Path -Directory -ErrorAction SilentlyContinue | Where-Object {
        (Test-Path -LiteralPath (Join-Path $_.FullName 'mod.info')) -or (Test-Path -LiteralPath (Join-Path $_.FullName 'common\mod.info'))
    } | Select-Object -First 1
    return [bool]$hit
}

$ws = Join-Path $z 'workshop_src'
$wsMode = $null

if (Test-WorkshopRoot $ws) {
    $wsMode = 'id'
} elseif (Test-Path -LiteralPath $ws) {
    $ans = AskYesNo (L "找到了 workshop_src 文件夹，但里面没有工坊原始包。`n是否手动选择工坊原始包所在文件夹？" "workshop_src exists but has no workshop packages.`nDo you want to select the workshop source folder manually?")
    if (-not $ans) { return }
} else {
    ShowInfo (L "在独立版目录下没有找到 workshop_src 文件夹。`n（直接复制 mods 实体文件的话可以忽略，下一步会让你手动指定）" "workshop_src was not found under the standalone folder.`n(If mods are real folders, ignore this; you will pick the source in the next step.)") (L "未找到 workshop_src" "workshop_src not found")
}

if (-not $wsMode) {
    while ($true) {
        $pick = PickFolder (L "② 请选择【工坊原始包所在文件夹】`n通常是 Zomboid\workshop_src，或 Steam 的 steamapps\workshop\content\108600" "2) Select the WORKSHOP SOURCE folder.`nUsually Zomboid\workshop_src, or Steam's steamapps\workshop\content\108600") $z
        if (-not $pick) { return }
        if (Test-WorkshopRoot $pick) { $ws = $pick; $wsMode = 'id'; break }
        if (Test-FlatModRoot $pick)  { $ws = $pick; $wsMode = 'flat'; break }
        ShowInfo (L "这个文件夹里既没有『数字工坊ID\mods』结构，`n也没有直接可用的 mod 文件夹（含 mod.info）。`n请重新选择。" "This folder has neither a numeric workshop-ID\mods structure nor any mod folder with mod.info.`nPlease pick again.") (L "路径无效" "Invalid folder")
    }
}

# ---------- 3. 检查并清理失效联接 / inspect and clean up ----------
$oldLinks = Get-ChildItem -LiteralPath $mods -Directory -ErrorAction SilentlyContinue | Where-Object { $_.LinkType -eq 'Junction' }
$dangling = @()
foreach ($l in $oldLinks) {
    $t = $l.Target
    $tp = if ($t -is [array]) { $t[0] } else { $t }
    if (-not $tp -or -not (Test-Path -LiteralPath $tp)) { $dangling += $l }
}
$modeText = if ($wsMode -eq 'id') { (L "工坊ID\mods" "workshop-id\mods") } else { (L "扁平mod文件夹" "flat mod folders") }
$summaryZh = "独立版根目录：$root`n工坊源目录：$ws`n源结构：$modeText`n`n现有联接 $($oldLinks.Count) 个，其中失效 $($dangling.Count) 个。`n`n将删除全部旧联接（只删链接，不动真实文件），`n并按版本择优重新生成。继续？"
$summaryEn = "Standalone root : $root`nWorkshop source : $ws`nSource layout   : $modeText`n`nExisting junctions: $($oldLinks.Count), dangling: $($dangling.Count).`n`nAll old junctions will be removed (links only, real files untouched)`nand rebuilt with version preference. Continue?"
if (-not (AskYesNo (L $summaryZh $summaryEn) (L "确认重建联接" "Rebuild junctions"))) { return }

foreach ($l in $oldLinks) {
    try { [System.IO.Directory]::Delete($l.FullName, $false) } catch { }
}

# ---------- 4. 收集候选并择优 / collect candidates ----------
function Get-ModInfoText {
    param([string]$Dir)
    foreach ($c in @((Join-Path $Dir 'mod.info'), (Join-Path $Dir 'common\mod.info'))) {
        if (Test-Path -LiteralPath $c) { return (Get-Content -LiteralPath $c -Raw -ErrorAction SilentlyContinue) }
    }
    $found = Get-ChildItem -LiteralPath $Dir -Recurse -Depth 2 -Filter 'mod.info' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { return (Get-Content -LiteralPath $found.FullName -Raw -ErrorAction SilentlyContinue) }
    return $null
}

function Parse-Ver {
    param([string]$Text, [string]$Key)
    if (-not $Text) { return $null }
    if ($Text -match "(?m)^\s*$Key\s*=\s*([0-9]+(?:\.[0-9]+)*)") {
        try { return [version]$Matches[1] } catch { return $null }
    }
    return $null
}

$candidates = @{}
if ($wsMode -eq 'id') {
    foreach ($id in (Get-ChildItem -LiteralPath $ws -Directory | Where-Object { $_.Name -match '^\d+$' })) {
        $inner = Join-Path $id.FullName 'mods'
        if (-not (Test-Path -LiteralPath $inner)) { continue }
        foreach ($d in (Get-ChildItem -LiteralPath $inner -Directory -ErrorAction SilentlyContinue)) {
            $name = $d.Name.Trim()
            if (-not $candidates.ContainsKey($name)) { $candidates[$name] = New-Object System.Collections.ArrayList }
            $txt = Get-ModInfoText $d.FullName
            $mv = Parse-Ver $txt 'modversion'; if (-not $mv) { $mv = [version]'0.0' }
            $vm = Parse-Ver $txt 'versionMin'; if (-not $vm) { $vm = [version]'0.0' }
            $wid = 0L; [void][long]::TryParse($id.Name, [ref]$wid)
            [void]$candidates[$name].Add([pscustomobject]@{ Path=$d.FullName; Workshop=$id.Name; ModVersion=$mv; VersionMin=$vm; Id=$wid })
        }
    }
} else {
    foreach ($d in (Get-ChildItem -LiteralPath $ws -Directory -ErrorAction SilentlyContinue)) {
        $name = $d.Name.Trim()
        if (-not $candidates.ContainsKey($name)) { $candidates[$name] = New-Object System.Collections.ArrayList }
        $txt = Get-ModInfoText $d.FullName
        $mv = Parse-Ver $txt 'modversion'; if (-not $mv) { $mv = [version]'0.0' }
        $vm = Parse-Ver $txt 'versionMin'; if (-not $vm) { $vm = [version]'0.0' }
        [void]$candidates[$name].Add([pscustomobject]@{ Path=$d.FullName; Workshop='local'; ModVersion=$mv; VersionMin=$vm; Id=0L })
    }
}

# ---------- 5. 生成联接 / create junctions ----------
$created = 0; $skip = @(); $fail = @()
foreach ($name in ($candidates.Keys | Sort-Object)) {
    $sorted = $candidates[$name] | Sort-Object -Property @{Expression={$_.ModVersion};Descending=$true},
                                                      @{Expression={$_.VersionMin};Descending=$true},
                                                      @{Expression={$_.Id};Descending=$true}
    $w = $sorted[0]
    if ($sorted.Count -gt 1) {
        foreach ($o in ($sorted | Select-Object -Skip 1)) {
            $skip += (L "同名弃用 $name ：保留 $($w.Workshop) v$($w.ModVersion)，丢弃 $($o.Workshop) v$($o.ModVersion)" "duplicate dropped: $name -> kept $($w.Workshop) v$($w.ModVersion), dropped $($o.Workshop) v$($o.ModVersion)")
        }
    }
    $link = Join-Path $mods $name
    if (Test-Path -LiteralPath $link) { $skip += (L "目标已存在: $name" "target exists: $name"); continue }
    $null = & cmd /c mklink /J "$link" "$($w.Path)" 2>&1
    if (Test-Path -LiteralPath $link) { $created++ } else { $fail += "$name : mklink failed" }
}

# ---------- 6. 重写便携启动 bat / rewrite portable launcher ----------
$bat = "@echo off`r`ncd /d `"%~dp0ProjectZomboid`"`r`nstart `"`" `"%~dp0ProjectZomboid\ProjectZomboid64.exe`" -agentlib:zbNative=policy=allow-all -- -cachedir=`"%~dp0Zomboid`" -modfolders mods`r`nexit`r`n"
[System.IO.File]::WriteAllText((Join-Path $root '启动独立版_Start.bat'), $bat, [System.Text.Encoding]::ASCII)

# ---------- 7. 输出 Steam 参数说明 / Steam launch options ----------
$steam = @"
Project Zomboid 独立版 —— Steam 非Steam游戏 参数
Project Zomboid Standalone - Steam non-Steam game settings

目标     (Target)     : $game\ProjectZomboid64.exe
起始位置 (Start In)   : $game
启动选项 (Launch Opts): -agentlib:zbNative=policy=allow-all -- -cachedir="$z" -modfolders mods

说明 / Notes：
1) -cachedir 必须是本机真实绝对路径，带空格要保留引号
   -cachedir must be a real absolute path on this machine; keep the quotes if it contains spaces
2) -modfolders 只能写关键字 mods，不能写磁盘路径
   -modfolders only accepts the keyword "mods", not a folder path
3) 换电脑或换目录后，本文件里的路径需要同步更新
   运行【迁移修复_Repair.bat / Migration Repair】会重新生成本文件
   After moving to another PC this file is regenerated by the migration repair tool
"@
$steam = ($steam -replace "`r`n","`n") -replace "`n","`r`n"
[System.IO.File]::WriteAllText((Join-Path $root 'Steam启动参数_SteamOptions.txt'), $steam, (New-Object System.Text.UTF8Encoding($true)))

# ---------- 8. 结果 / result ----------
$links = Get-ChildItem -LiteralPath $mods -Directory -ErrorAction SilentlyContinue | Where-Object { $_.LinkType -eq 'Junction' }
$bad = @()
foreach ($d in $links) {
    $has = (Test-Path -LiteralPath (Join-Path $d.FullName 'mod.info')) -or
           (Test-Path -LiteralPath (Join-Path $d.FullName 'common\mod.info')) -or
           (Get-ChildItem -LiteralPath $d.FullName -Recurse -Depth 2 -Filter 'mod.info' -ErrorAction SilentlyContinue | Select-Object -First 1)
    if (-not $has) { $bad += $d.Name }
}

$badText = if ($bad.Count) { "（" + ($bad -join '、') + "）" } else { "" }
$badTextEn = if ($bad.Count) { " (" + ($bad -join ', ') + ")" } else { "" }

$doneZh = @"
迁移修复完成

独立版根目录：$root
工坊源目录：$ws

联接：新建 $created 个，当前共 $($links.Count) 个
跳过 $($skip.Count) 个，失败 $($fail.Count) 个
无 mod.info 的：$($bad.Count) 个$badText

已生成：
  启动独立版_Start.bat（便携版，换目录直接双击）
  Steam启动参数_SteamOptions.txt（里面是要填进 Steam 的三项内容）

下一步：把 Steam启动参数_SteamOptions.txt 里的三项照抄进
Steam 库 → 该项目右键 → 属性 → 目标/起始位置/启动选项
"@
$doneEn = @"
Migration repair finished

Standalone root : $root
Workshop source : $ws

Junctions: created $created, total now $($links.Count)
skipped $($skip.Count), failed $($fail.Count)
without mod.info: $($bad.Count)$badTextEn

Generated:
  launcher bat (portable, double-click anywhere)
  Steam launch options txt (three values to paste into Steam)

Next: copy the three values from that txt into
Steam Library -> right-click the entry -> Properties -> Target / Start In / Launch Options
"@
ShowInfo (L $doneZh $doneEn) (L "完成" "Done")
