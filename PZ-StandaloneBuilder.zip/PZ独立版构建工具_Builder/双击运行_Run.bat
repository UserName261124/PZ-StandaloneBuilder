@echo off
chcp 65001 >nul
title Project Zomboid Offline Builder
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0builder.ps1"
if errorlevel 1 pause
exit